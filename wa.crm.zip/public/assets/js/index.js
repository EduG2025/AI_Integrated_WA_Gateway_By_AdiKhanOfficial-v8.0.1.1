function _0x3522() {
  const _0x34a2f6 = ['appendChild','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20©\x20Byte\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22col-sm-6\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22text-sm-end\x20d-none\x20d-sm-block\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20Developed\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20by\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<a\x20href=\x22https://adikhanofficial.com\x22>AdiKhanOfficial</a>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x20\x20\x20\x20','div','8684952lgulfx','349731gkXYqj','12CTgiNx','292518UqxgAW','847806IHXCxO','className','\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22container-fluid\x22>\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22row\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22col-sm-6\x22>\x20\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','footer','1867704buVAkg','7EczXSF','40tJXqbd','1301076JaaYbD','11OXLmBE','createElement','28860qDyTky','20EvXnRZ','getFullYear','querySelector','.wrapper'];
  _0x3522 = function () {
    return _0x34a2f6;
  };
  return _0x3522();
}
function _0xb744(_0x581499, _0x1af161) {
  const _0x35225b = _0x3522();
  return (
    (_0xb744 = function (_0xb74460, _0x521e8f) {
      _0xb74460 = _0xb74460 - 0x12c;
      let _0x1f39e9 = _0x35225b[_0xb74460];
      return _0x1f39e9;
    }),
    _0xb744(_0x581499, _0x1af161)
  );
}
(function (_0x165413, _0x2084ad) {
  const _0x220321 = _0xb744,
    _0x265ac3 = _0x165413();
  while (!![]) {
    try {
      const _0x3a19d7 =
        -parseInt(_0x220321(0x130)) / 0x1 +
        parseInt(_0x220321(0x12d)) / 0x2 +
        (parseInt(_0x220321(0x13b)) / 0x3) *
          (parseInt(_0x220321(0x13a)) / 0x4) +
        (-parseInt(_0x220321(0x131)) / 0x5) *
          (-parseInt(_0x220321(0x13c)) / 0x6) +
        (-parseInt(_0x220321(0x141)) / 0x7) *
          (parseInt(_0x220321(0x140)) / 0x8) +
        (parseInt(_0x220321(0x139)) / 0x9) *
          (-parseInt(_0x220321(0x12c)) / 0xa) +
        (-parseInt(_0x220321(0x12e)) / 0xb) *
          (parseInt(_0x220321(0x138)) / 0xc);
      if (_0x3a19d7 === _0x2084ad) break;
      else _0x265ac3["push"](_0x265ac3["shift"]());
    } catch (_0x119d79) {
      _0x265ac3["push"](_0x265ac3["shift"]());
    }
  }
})(_0x3522, 0x598a3),
  $(document)["ready"](function () {
    const _0x1610d0 = _0xb744;
    let _0x35d13c = new Date()[_0x1610d0(0x132)]();
    var _0x43d791 = document[_0x1610d0(0x12f)](_0x1610d0(0x137));
    (_0x43d791[_0x1610d0(0x13d)] = _0x1610d0(0x13f)),
      (_0x43d791["innerHTML"] =
        _0x1610d0(0x13e) + _0x35d13c + _0x1610d0(0x136)),
      document[_0x1610d0(0x133)](_0x1610d0(0x134))[_0x1610d0(0x135)](_0x43d791);
  });
