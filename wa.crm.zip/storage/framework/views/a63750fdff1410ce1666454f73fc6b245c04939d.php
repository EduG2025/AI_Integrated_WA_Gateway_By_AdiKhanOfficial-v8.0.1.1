<tr>

    <td colspan="<?php echo e($colspan); ?>" class="text-center">
        <div class="d-flex flex-column align-items-center">
           
        <img src="<?php echo e(asset('assets/images/no-data.svg')); ?>" alt="No Data" class="img-fluid">
       <h5><?php echo e($text); ?></h5>
        </div>
    </td>
</tr><?php /**PATH /Users/ilmans/Documents/Projects/Laravel/whatsapp-gateway/resources/views/components/no-data.blade.php ENDPATH**/ ?>