<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout-dashboard','data' => ['title' => ''.e(__('Update Version')).'']]); ?>
<?php $component->withName('layout-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('Update Version')).'']); ?>
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <div class="breadcrumb-title pe-3"><?php echo e(__('Admin')); ?></div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('Update Version')); ?></li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->
    <?php if(session()->has('alert')): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('type', session('alert')['type']); ?>
            <?php $__env->slot('msg', session('alert')['msg']); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row mt-4">
        <div class="col">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h5 class="card-title"><?php echo e(__('Update')); ?></h5>
                </div>
                <div class="container mt-3">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($updateAvailable): ?>
                        <div class="alert alert-info">
                            <?php echo e(__('A new version is available:')); ?> <span
                                class="text-danger">v<?php echo e($newVersion); ?></span><br />
                            <?php echo __(
                                '<span class="text-danger">Note: Turn off <span class="text-primary">Nodejs</span> before continuing with the update, after the update is complete you can turn it back on</span>',
                            ); ?>

                            <?php if($whatsNew): ?>
                                <br /><?php echo $whatsNew; ?>

                            <?php endif; ?>
                        </div>
                        <form method="POST" action="<?php echo e(route('update.install')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php if($serverProtocol == 'https'): ?>
                                <div class="alert alert-danger">
                                    <?php echo __(
                                        '<span class="text-danger">You are using SSL in the <span class="text-primary">server.js</span> file, but don\'t worry, <span class="text-primary">Smart Update</span> will update and run your site with SSL, just click update</span>',
                                    ); ?><br />
                                    <?php if($updateSSL): ?>
                                        <input type="hidden" name="ssl" value="ssl" />
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <?php if($before): ?>
                                <input type="hidden" name="before" value="1" />
                            <?php endif; ?>
                            <?php if($after): ?>
                                <input type="hidden" name="after" value="1" />
                            <?php endif; ?>
                            <input type="hidden" name="version" value="<?php echo e($newVersion); ?>" />
                            <button type="submit" class="btn btn-primary mb-3"><?php echo e(__('Update')); ?></button>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-success">
                            <?php echo e(__('You are using the latest version.')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home2/adikhanofficial/wabeta.adikhanofficial.com/resources/views/pages/admin/update.blade.php ENDPATH**/ ?>