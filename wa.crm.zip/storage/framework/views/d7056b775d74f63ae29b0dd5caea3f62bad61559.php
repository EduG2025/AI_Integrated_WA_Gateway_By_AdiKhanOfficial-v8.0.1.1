<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout-dashboard','data' => ['title' => 'Settings Server ']]); ?>
<?php $component->withName('layout-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'Settings Server ']); ?>
    <!--breadcrumb-->
    <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
        <div class="breadcrumb-title pe-3">Admin</div>
        <div class="ps-3">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 p-0">
                    <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Setting Server</li>
                </ol>
            </nav>
        </div>
    </div>
    <!--end breadcrumb-->

    <?php if(session()->has('alert')): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => []]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <?php $__env->slot('type', session('alert')['type']); ?>
            <?php $__env->slot('msg', session('alert')['msg']); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row">

        <div class="col">
            <div class="page-description page-description-tabbed">


                <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="account-tab" data-bs-toggle="tab" data-bs-target="#server"
                            type="button" role="tab" aria-controls="hoaccountme"
                            aria-selected="true">Server</button>
                    </li>


                </ul>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col">
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="server" role="tabpanel" aria-labelledby="account-tab">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row m-t-lg">
                                        <form action="<?php echo e(route('setServer')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-md-12">
                                                <label for="typeServer"
                                                    class="form-label"><?php echo e(__('Server Type')); ?></label>
                                                <select name="typeServer" class="form-control" id="server" required>

                                                    <?php if(env('TYPE_SERVER') === 'localhost'): ?>
                                                        <option value="localhost" selected><?php echo e(__('Localhost')); ?>

                                                        </option>
                                                        <option value="hosting"><?php echo e(__('Hosting Shared')); ?></option>
                                                        <option value="other"><?php echo e(__('Other')); ?></option>
                                                    <?php elseif(env('TYPE_SERVER') === 'hosting'): ?>
                                                        <option value="localhost"><?php echo e(__('Localhost')); ?></option>
                                                        <option value="hosting" selected><?php echo e(__('Hosting Shared')); ?>

                                                        </option>
                                                        <option value="other"><?php echo e(__('Other')); ?></option>
                                                    <?php else: ?>
                                                        <option value="other" required><?php echo e(__('Other')); ?></option>
                                                        <option value="localhost"><?php echo e(__('Localhost')); ?></option>
                                                        <option value="hosting"><?php echo e(__('Hosting Shared')); ?></option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-12">
                                                <label for="Port"
                                                    class="form-label"><?php echo e(__('Port Node JS')); ?></label>
                                                <input type="number" name="portnode" class="form-control"
                                                    id="Port" value="<?php echo e(env('PORT_NODE')); ?>" required>
                                            </div>
                                    </div>
                                    <div
                                        class="row m-t-lg <?php echo e(env('TYPE_SERVER') === 'other' ? 'd-block' : 'd-none'); ?> formUrlNode">
                                        <div class="col-md-12">
                                            <label for="settingsInputUserName "
                                                class="form-label"><?php echo e(__('URL Node')); ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text"
                                                    id="settingsInputUserName-add"><?php echo e(__('URL')); ?></span>
                                                <input type="text" class="form-control"
                                                    value="<?php echo e(env('WA_URL_SERVER')); ?>" name="urlnode"
                                                    id="settingsInputUserName"
                                                    aria-describedby="settingsInputUserName-add">
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row m-t-lg ">
                                        <div class="col mt-4">

                                            <button type="submit"
                                                class="btn btn-primary btn-sm"><?php echo e(__('Update')); ?></button>
                                        </div>
                                    </div>
                                </div>
                                <div
                                    class="col-md-6 mt-3 p-2 border rounded d-flex align-items-center justify-content-center flex-column">
                                    <div>
                                        <h4><?php echo e(__('Port (:port) Is', ['port' => $port])); ?>

                                            <?php echo e($isConnected ? __('Connected') : __('Disconnected')); ?></h4>
                                    </div>
                                    <div>
                                        <h1><?php echo e($isConnected ? '✅' : '❌'); ?></h1>
                                    </div>

                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h5 class="text-center"><?php echo e(__('Generate SSL For Your NodeJS')); ?></h5>
                                    <div class="text-center">
                                        <form action="<?php echo e(route('generateSsl')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label for="settingsInputUserName "
                                                        class="form-label"><?php echo e(__('Domain')); ?></label>
                                                    <input type="text" name="domain" class="form-control"
                                                        id="domain" value="<?php echo e($host); ?>" required readonly
                                                        <?php if($host === 'localhost'): ?> disabled <?php endif; ?>>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="settingsInputUserName "
                                                        class="form-label"><?php echo e(__('Email')); ?></label>
                                                    <input type="email" name="email" class="form-control"
                                                        id="email" value="" required
                                                        <?php if($host === 'localhost'): ?> readonly disabled <?php endif; ?>>
                                                </div>
                                            </div>
                                            <?php if($host == 'localhost' || $host == 'hosting'): ?>
                                                <button type="submit" class="btn btn-danger btn-sm mt-3"
                                                    disabled><?php echo e(__('Ssl only required in vps if you want to access via ssl')); ?></button>
                                            <?php else: ?>
                                                <button type="submit"
                                                    class="btn btn-primary btn-sm mt-3"><?php echo e(__('Generate SSL Certificate')); ?></button>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>


    <script>
        $('#server').on('change', function() {
            let type = $('#server :selected').val();
            console.log(type);
            if (type === 'other') {
                $('.formUrlNode').removeClass('d-none')
            } else {
                $('.formUrlNode').addClass('d-none')

            }
        })
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH /home2/adikhanofficial/wabeta.adikhanofficial.com/resources/views/pages/admin/settings.blade.php ENDPATH**/ ?>