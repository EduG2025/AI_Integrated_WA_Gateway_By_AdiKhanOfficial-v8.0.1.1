<?php

namespace App\Http\Controllers;


class FileManagerController extends Controller
{
    //

    public function index(){
        return view('pages.file-manager');
    }
}
